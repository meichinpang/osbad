import os
import pathlib


def find_repo_root(marker):
    """Find the project root directory."""
    current_dir = pathlib.Path(os.getcwd())
    while True:
        if (current_dir / marker).exists():
            return current_dir
        parent_dir = current_dir.parent
        if parent_dir == current_dir:
            # We've reached the root directory
            break
        current_dir = parent_dir
    raise FileNotFoundError(
        f"Marker file '{marker}' not found in any parent directories.")

if __name__ == "__main__":
    repo_root_path = find_repo_root("pyproject.toml")

    if repo_root_path.exists():
        print(f"Found repo root: {repo_root_path}")
    else:
        print("Repo root not found.")